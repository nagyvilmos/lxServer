/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package lexa.core.server.connection;

import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import lexa.core.comms.Session;
import lexa.core.data.ConfigData;
import lexa.core.data.exception.DataException;
import lexa.core.server.ProcessException;
import lexa.core.server.context.Config;

/**
 *
 * @author Felhasználó
 */
class RemoteHost {
    private final String name;
    private final InetAddress ipAddress;
    private final Integer port;

    RemoteHost(String name, ConfigData config)
            throws DataException,
                    ProcessException {
        this.name = name;
        try {
            this.ipAddress = Inet4Address.getByName(
                    config.getSetting(Config.HOST));
        } catch (UnknownHostException ex) {
            throw new ProcessException("Unable to determine remote host " + name, ex);
        }
        this.port = config.getItem(Config.PORT).getInteger();
    }

	String getName() {
		return this.name;
				
	} 
    /**
     * get a session to the remote host.
     *
     * @return  a session to the remote host
     */
    Session getSession()
            throws ProcessException {
        try {
            Socket socket = new Socket(this.ipAddress, this.port);
            return new Session(socket);
        } catch (IOException ex) {
            throw new ProcessException("Unable to create session for host " + this.name, ex);
        }
    }

}
