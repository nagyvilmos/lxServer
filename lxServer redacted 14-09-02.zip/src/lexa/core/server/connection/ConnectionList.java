/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package lexa.core.server.connection;

import java.util.HashMap;
import java.util.Map;
import lexa.core.data.ConfigData;
import lexa.core.data.exception.DataException;
import lexa.core.server.MessageBroker;
import lexa.core.server.ProcessException;
import lexa.core.server.context.Config;
import lexa.core.server.context.Value;

/**
 *
 * @author william
 */
public class ConnectionList
{
    /** The ID of the last session created */
    private int lastSessionId;
	/** the config for all the remote hosts */
	private final HashMap<String, RemoteHost> remoteHosts;
    /** All active connections */
    private final Map<Integer, Connection> connections;

	private MessageBroker messageBroker;

	public ConnectionList(ConfigData config)
			throws DataException,
					ProcessException
	{
        //load the list of remote hosts:
        this.remoteHosts = new HashMap<String, RemoteHost>();
        if (config != null) {
            String[] brokerNames = config.keys();
            for (int b = 0;
                    b < brokerNames.length;
                    b++) {
                String broker = brokerNames[b];
                ConfigData brokerConfig = config.getConfigData(broker);
                if (this.remoteHosts.containsKey(broker)) {
                    throw new ProcessException("Config contains duplicate remote hosts: " + broker);
                }
                this.remoteHosts.put(broker, new RemoteHost(broker, brokerConfig));
                brokerConfig.close();
            }
        }
		this.lastSessionId = 0;
        this.connections = new HashMap<Integer, Connection>();
	}

	public synchronized Connection newConnection(String connectionName) throws ProcessException
	{
        int id = ++this.lastSessionId;
        Connection connection;
        if (Value.LOCAL.equals(connectionName)) {
            connection = new LocalConnection(this.messageBroker, id);
        } else {
            RemoteHost remote = this.remoteHosts.get(connectionName);

            if(remote == null) {
                throw new ProcessException("Unknown connection destination " + connectionName);
            }
            connection = new RemoteConnection(this.messageBroker, id, remote);
        }
        this.connections.put(connection.getId(),connection);
		connection.start();
        return connection;
	}

	public Connection getConnection(int connection)
	{
		return this.connections.get(connection);
	}

	public void close()
	{
        // tell the connections you're dead:
        for (Connection c : this.connections.values()) {
            c.close();
        }
	}

	public void setMessageBroker(MessageBroker messageBroker)
	{
		this.messageBroker=messageBroker;
	}
	
}
