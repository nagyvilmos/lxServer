/**
 * The Lexa messaging sub-system.
 *
 * <p>The main component is the broker.  This contains all the services that
 * run the processes and provides connections for submitting requests.
 *
 * @since 2013-04
 *
 * @link lexa.core.server.MessageBroker
 * @link lexa.core.server.Service
 * @link lexa.core.server.ProcessAgent
 */
package lexa.core.server;
