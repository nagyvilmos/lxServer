/*
 * ================================================================================
 * Lexa - Property of William Norman-Walker
 * --------------------------------------------------------------------------------
 * Service.java
 *--------------------------------------------------------------------------------
 * Author:  William Norman-Walker
 * Created: July 2013
 *--------------------------------------------------------------------------------
 * Change Log
 * Date:        By: Ref:        Description:
 * ----------   --- ----------  --------------------------------------------------
 * -            -   -           -
 *================================================================================
 */
package lexa.core.server;

import lexa.core.server.connection.Connection;
import lexa.core.data.DataSet;

/**
 * Interface for any service supported by the {@link MessageBroker}
 * @author  William
 * @since   2013-07
 */
interface Service {

    /**
     * Close the service.
     */
    public void close();

    /**
     * Start the service running.
     */
    public void start()
            throws ProcessException;

    /**
     * Submit an inbound message.
     *
     * <p>An inbound message is received from the {@link MessageBroker} and
     * will be passed onto the handler depending on the message.
     * @param   message
     *          a {@link DataSet} containing the inbound message}
     */
    public void inbound(DataSet message);

    /**
     * Submit an outbound message.
     *
     * <p>An outbound message is sent to the {@link MessageBroker}.
     * @param   message
     *          a {see DataSet} containing the outbound message}
     */
    public void outbound (DataSet message);

    /**
     * Sets the {@link MessageBroker} that contains this service.
     * @param   messageBroker
     *          the message broker
     */
    public void setMessageBroker(MessageBroker messageBroker);

    /**
     * Get a connection from the {@link MessageBroker}
     *
     * @param   connectionName
     *          The name of remote message broker; or {@link lexa.core.server.context.Value#LOCAL LOCAL} for the
     *          local message broker.
     *
     * @return  a new connection to the named message broker;
     *          or {@code null} if no connection could be established.
     * @throws  ProccessException
     *          when the connection cannot be retrieved.
     */
    public Connection getConnection(String connectionName)
            throws ProcessException;

}


