/*
 * ================================================================================
 * Lexa - Property of William Norman-Walker
 * --------------------------------------------------------------------------------
 * HostService.java
 *--------------------------------------------------------------------------------
 * Author:  William Norman-Walker
 * Created: May 2013
 *--------------------------------------------------------------------------------
 * Change Log
 * Date:        By: Ref:        Description:
 * ----------   --- ----------  --------------------------------------------------
 * -            -   -           -
 *================================================================================
 */
package lexa.core.server;

import lexa.core.server.connection.Connection;
import lexa.core.data.DataSet;
import lexa.core.logging.Logger;

/**
 * Acts as a server providing status management of all other servers
 *
 * @author William
 * @since 2013-04
 */
class HostService
    implements Service {

    /** logger for events */
    private final Logger logger;
    /** A link back to the broker that created this service */
    private MessageBroker messageBroker;

    /**
     * Create the host service
     */
    HostService () {
        this.logger = new Logger(HostService.class.getSimpleName(),"host");
    }

    @Override
    public void close() {
        // nothing to do.
    }

    @Override
    public void start()
            throws ProcessException {
        // nothing to do
    }

    @Override
    public void inbound(DataSet message) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void outbound(DataSet message) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setMessageBroker(MessageBroker messageBroker) {
        this.messageBroker = messageBroker;
    }

    @Override
    public Connection getConnection(String connectionName)
            throws ProcessException {
        return this.messageBroker.getConnection(connectionName);
    }
}
