package lexa.core.server;

import lexa.core.server.connection.Connection;
import java.util.*;
import lexa.core.data.ConfigData;
import lexa.core.data.DataSet;
import lexa.core.data.exception.DataException;
import lexa.core.expression.ExpressionException;
import lexa.core.expression.function.FunctionLibrary;
import lexa.core.logging.Logger;
import lexa.core.queue.FIFOQueue;
import lexa.core.queue.Queue;
import lexa.core.server.connection.ConnectionList;
import lexa.core.server.connection.RemoteConnection;
import lexa.core.server.connection.LocalConnection;
import lexa.core.server.context.Config;
import lexa.core.server.context.Context;
import lexa.core.server.context.Value;

/**
 * A message broker to provide asynchronous message services to callers.
 *
 * <p>The server consists of a list of one or more services, each supporting one or
 * more processes.  As a general principle, the process agents will perform one specific
 * task.
 * <p>The configuration for a message broker is:
 * <pre>
 * name &lt;brokerName&gt;
 * [wildcard &lt;wildcardService&gt;]
 * [timeout &lt;timeout&gt;]
 * [brokerList {
 *   &lt;connectionName&gt; {
 *     ipAddress &lt;ipAddress&gt;
 *     port % &lt;port&gt;
 *   }
 * }
 * [logging {
 *   &lt;logging config&gt; {
 * }]
 * serviceList {
 *   &lt;serviceName&gt; {
 *       &lt;service config&gt;
 *   }
 *   [...]
 * }
 * </pre>
 * <p>Where:
 * <dl>
 * <dt>&lt;brokerName&gt;</dt><dd>a unique name for the message broker.</dd>
 * <dt>&lt;wildcardService&gt;</dt><dd>the name of a service in the service list;
 *      unknown services are rerouted to this service. [optional]</dd>
 * <dt>&lt;timeout&gt;</dt><dd>period in milliseconds after which messages will expire
 *      if no response has been received; a value of {@code 0} represents no timeout.
 *      [optional; default value is 30000.]
 * <dt>&lt;connectionName&gt;</dt><dd>a unique name for a remote message broker;
 *      the name "{@code local}" may not be used.</dd>
 * <dt>&lt;ipAddress&gt;</dt><dd>the IP address for a remote message broker.</dd>
 * <dt>&lt;port&gt;</dt><dd>the port for a remote message broker.</dd>
 * <dt>&lt;logging config&gt;</dt><dd>the configuration for the logging service;
 *      see {@link lexa.core.logging.LogLevels}</dd>
 * <dt>&lt;serviceName&gt;</dt><dd>a unique name within the broker for a service;
 *      the name {@code host} may not be used.</dd>
 * <dt>&lt;service config&gt;</dt><dd>the configuration for the service;
 *      see {@link ConfigService}.</dd>
 * </dl>
 *
 * @author William
 * @since 2014-04
 */
public class MessageBroker
        extends Thread {
    /** The name of the host service; "{@code host}" */
    private static final String HOST_SERVICE    = "host";

    /** Narrative name */
    private final String name;
    /** logger for events */
    private final Logger logger;
    /** the queue of inbound requests */
    private final Queue queue;
	/** times for messages being received */
    private final ArrayList<MessageKey> receivedTimes;
    /** Wildcard service for re-routing unknown messages */
    private final String wildcard;
    /** Timeout period for expiring messages */
    private final int timeout;
    /** The available services */
    private final Map<String, Service> services;
    /** Indicate if the broker is in a running state */
    private boolean running;
	/** a list of connection destinations */
	private final ConnectionList connectionList;

    /**
     * Create a new message broker from the supplied config.
     *
     * @param   config
     *          the configuration for the message broker.
     * @throws  DataException
     *          when there is a problem in the configuration.
     * @throws  ProcessException
     *          when an exception occurs within the processes.
	 * @throws lexa.core.expression.ExpressionException
	 * @throws java.lang.ClassNotFoundException
	 * @throws java.lang.InstantiationException
	 * @throws java.lang.IllegalAccessException
     */
    public MessageBroker(ConfigData config)
            throws DataException, ProcessException, ExpressionException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        this(config, null);
    }
    /**
     * Create a new message broker from the supplied config.
     *
     * @param   config
     *          the configuration for the message broker.
     * @param   functionLibrary
     *          a library of functions to use for config driven processes.
     * @throws  DataException
     *          when there is a problem in the configuration.
     * @throws  ProcessException
     *          when an exception occurs within the processes.
	 * @throws lexa.core.expression.ExpressionException
	 * @throws java.lang.ClassNotFoundException
	 * @throws java.lang.InstantiationException
	 * @throws java.lang.IllegalAccessException
     */
    public MessageBroker(ConfigData config, FunctionLibrary functionLibrary)
            throws DataException, ProcessException, ExpressionException, ClassNotFoundException, InstantiationException, IllegalAccessException {

        this.name = config.getSetting(Config.NAME);
        this.logger = new Logger(MessageBroker.class.getSimpleName() , this.name);
		ConfigData loggingConfig = config.contains(Config.LOGGING) ?
                config.getConfigData(Config.LOGGING) :
                null;
        if (loggingConfig != null) {
            Logger.logLevels().setLogging(loggingConfig);
            loggingConfig.close();
        }

        this.wildcard = config.getOptionalSetting(Config.WILDCARD);

        this.timeout = (config.contains(Config.TIMEOUT)) ?
                config.getItem(Config.TIMEOUT).getInteger():
                Value.DEFAULT_TIMEOUT;
        this.receivedTimes = new ArrayList<MessageKey>();

		ConfigData brokerList = (config.contains(Config.BROKER_LIST)) ?
				config.getConfigData(Config.BROKER_LIST) :
				null;
		this.connectionList = new ConnectionList(brokerList);
		if (brokerList != null) {
			brokerList.close();
		}

		// if needed we can always get a URLClassLoader to allow 
		// the explicit listing of jars to load.
		ClassLoader cl = ClassLoader.getSystemClassLoader();
        // create the services list
        this.services = new HashMap<String, Service>();
        this.services.put(MessageBroker.HOST_SERVICE, new HostService());
        ConfigData serviceList = config.getConfigData(Config.SERVICE_LIST);
        String[] serviceNames = serviceList.keys();
        for (int s = 0;
                s < serviceNames.length;
                s++) {
            ConfigData serviceConfig = serviceList.getConfigData(serviceNames[s]);
            if (this.services.containsKey(serviceNames[s])) {
                throw new ProcessException("Config contains duplicate service: " + serviceNames[s]);
            }
            this.services.put(serviceNames[s], new ConfigService(serviceNames[s], cl, serviceConfig, functionLibrary));
            serviceConfig.close();
        }
        serviceList.close();
        if (this.wildcard != null && !this.services.containsKey(this.wildcard)) {
            throw new ProcessException("Config missing wildcard service: " + this.wildcard);
        }

        this.queue = new FIFOQueue();
        this.logger.info("Initialised message broker " + this.name);
    }

    /**
     * Bounces a message back to the caller with a simple {@code return} value.
     * @param   message
     *          the original inbound message
     * @param   returnMessage
     *          a message to return to the caller
     */
    private void bounceBack(DataSet message, String returnMessage) {
        this.logger.debug("bounceBack " + returnMessage , message);
        message.put(Context.RETURN, returnMessage);
        message.put(Context.CLOSE, true);
        this.outbound(message);
    }

    /**
     * Check the state of the queue.
     *
     * <p>This is the main process for handling the inbound queue.
     * <p>If there are no pending messages then the thread sleeps until
     * it receives a notification, otherwise processes the first message
     * on the queue.
     */
    synchronized private void checkQueue() {
        if (this.queue.isEmpty()) {
            this.logger.debug("Queue waiting");
            try {
                this.wait(this.timeout);
            } catch (InterruptedException ex) {
                this.logger.error("Queue check interuption", ex);
            }
            this.logger.debug("Queue wake up");
            return;
        }
        processMessage(this.queue.get());
    }

    /**
     * Check the messages for any timeouts.
     */
    private void checkTimeout() {
        if (this.timeout == 0) {
            return;
        }
        Long expire = new Date().getTime() - this.timeout;
        while (this.receivedTimes.size() > 0 &&
                this.receivedTimes.get(0).timestamp < expire) {
            MessageKey mk = this.receivedTimes.get(0);
			Connection connection = this.connectionList.getConnection(mk.connection);
			if (connection != null) {
	            connection.timeout(mk.session);
			}
            this.receivedTimes.remove(0);
        }
    }

    /**
     * Close the message broker.
     *
     * <p>This stops the thread on which the broker is running, closes every
     * {@link Connection} and closes every {@link Service}.
     */
    public void close() {
        this.logger.info("closing");
		this.setRunning(false);
		this.connectionList.close();
        // tell the services they're dead
        for (Service s : this.services.values()) {
            s.close();
        }
        this.logger.info("closed");
    }

    /**
     * Get a connection for the local {@link MessageBroker}
     *
     * @return  a new connection to this broker.
     */
    public Connection getConnection()
            throws ProcessException {
        return this.getConnection(Value.LOCAL);
    }

    /**
     * Get a connection to a {@link MessageBroker}
     *
     * <p>The connection can be to this broker, using the name {@code LOCAL}, or
     * to any of the remote brokers defined in the {@code brokerList} section of
     * the configuration.
     *
     * <p> Calling {@code getConnection("LOCAL")} is equivalent to calling
     * {@link getConnection() getConnection()}
     *
     * @param   connectionName
     *          The name of a remote message broker; or {@code LOCAL} for the
     *          local message broker.
     *
     * @return  a new connection to the named message broker;
     *          or {@code null} if no connection could be established.
     *
     * @link MessageBroker#MessageBroker(lexa.core.data.ConfigData) MessageBroker(ConfigData config)
     */
    Connection getConnection(String connectionName)
            throws ProcessException {
		Connection connection = this.connectionList.newConnection(connectionName);
        this.logger.info("new connection " + connection.getId() + " to " + connectionName);
		return connection;
	}

    /**
     * Submit an inbound request to the broker.
     *
     * <p>The content of a request is structured as defined in {@link Message#getRequest(int, int)}.
     *
     * @param   message
     *          The {@link DataSet} containing the inbound request.
     */
    public synchronized void inbound(DataSet message) {
        this.logger.message("MESSAGE_IO", "inbound" ,message,null);
        this.receivedTimes.add(new MessageKey(
                message.getInteger(Context.CONNECTION_ID),
                message.getInteger(Context.SOURCE_ID)));
        this.queue.add(message);
        this.notifyAll();
    }

    /**
     * Indicates if the broker is currently running.
     *
     * @return  {@code true] if the broker is running,
     *          otherwise {@code false}.
     */
    public boolean isRunning() {
        return this.running;
    }


    /**
     * Return an outbound message to the original caller.
     *
     * <p>The message must include the header field {@code "connectionId"}
     * to identify the connection for the message.
     *
     * @param   message
     *          the message being sent back to the caller.
     */
    protected void outbound(DataSet message) {
        this.logger.message("MESSAGE_IO", "outbound" ,message,null);
        Integer cid = message.getInteger(Context.CONNECTION_ID);
        Integer sid = message.getInteger(Context.SOURCE_ID);
        Connection connection = this.connectionList.getConnection(cid);
        connection.reply(message);
        // remove from the list of messages
        for (int id = 0;
                id < this.receivedTimes.size();
                id++) {
            MessageKey mk = this.receivedTimes.get(id);
            if (mk.connection == cid) {
                if (mk.session == sid) {
                    this.receivedTimes.remove(id);
                    break;
                } else if (mk.session > sid) {
                    break;
                }
            }
        }
    }

    /**
     * Process a single inbound message.
     *
     * <p>This is called by {@link MessageBroker#checkQueue()} for each individual message.
     *
     * <p>This will put the message onto the queue of the {@link Service} identified by the
     * header field {@code "service"}.  If the service does not exist and there is not a configured
     * {@code "wildcard"} service, then the message is returned to the client with a response of
     * <b>{@code "unknown service"}</b>.
     *
     * @param   message
     *          an inbound message.
     */
    private void processMessage(DataSet message) {
        this.logger.debug("processMessage", message);
        String serviceName = message.getString(Context.SERVICE);
        Service service = this.services.get(serviceName);
        if (service == null) {
            if (this.wildcard != null) {
                service = this.services.get(this.wildcard);
            }
            if (service == null) {
                bounceBack(message, "unknown service");
                return;
            }
        }
        service.inbound(message);
    }

    /**
     * While the broker is running, check the message queue for any messages and place them on
     * the inbound list of the relevant services.
     */
    @Override
    public void run() {
        this.logger.info("Broker started");

        while (this.isRunning()) {
            checkQueue();
            checkTimeout();
        }

        this.logger.info("Broker stopped");
    }

    /**
     * Method to set the running state of the broker and then notify of the change.
     *
     * @param   running
     *          {@code true} for the broker is running,
     *          otherwise {@code false}.
     */
    private synchronized void setRunning(boolean running) {
        this.logger.debug("setRunning " + running);
        this.running = running;
        this.notifyAll();
    }

    /**
     * Start the message broker for processing messages.
     *
     * <p>This will first start each individual service and then set it's own state
     * to be running.
     */
    @Override
    public void start() {
        this.logger.info("starting");
        try {
			this.connectionList.setMessageBroker(this);
            for (Service s : this.services.values()) {
                s.setMessageBroker(this);
                s.start();
            }
            this.setRunning(true);
            super.start();
            this.logger.info("started");
        } catch (ProcessException ex) {
            this.logger.error("Unable to start messager broker", ex);
        }
    }

    private class MessageKey {
        private final int connection;
        private final int session;
        private final long timestamp;

        private MessageKey(int connection, int message) {
            this.timestamp = new Date().getTime();
            this.connection = connection;
            this.session = message;
        }
    }
}
