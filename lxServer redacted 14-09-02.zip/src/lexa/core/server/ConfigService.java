/*
 * ================================================================================
 * Lexa - Property of William Norman-Walker
 * --------------------------------------------------------------------------------
 * ConfigService.java
 *--------------------------------------------------------------------------------
 * Author:  William Norman-Walker
 * Created: April 2013
 *--------------------------------------------------------------------------------
 * Change Log
 * Date:        By: Ref:        Description:
 * ----------   --- ----------  --------------------------------------------------
 * -            -   -           -
 *================================================================================
 */
package lexa.core.server;

import lexa.core.server.connection.Connection;
import java.util.*;
import lexa.core.data.ConfigData;
import lexa.core.data.DataSet;
import lexa.core.data.exception.*;
import lexa.core.expression.ExpressionException;
import lexa.core.expression.function.FunctionLibrary;
import lexa.core.logging.*;
import lexa.core.server.context.*;

/**
 * A service set up using configuration.
 *
 * <p>The service is set up using config data provided by the {@link MessageBroker}.
 * Each service contains a set of {@link Process} agents that handle the messages.
 * <p>The configuration for a service is:
 * <pre>
 * &lt;serviceName&gt; {
 *   [wildcard &lt;wildcardProcess&gt;]
 *   processList {
 *     &lt;processName&gt; {
 *       &lt;process config&gt;
 *     }
 *     [...]
 *   }
 * }
 * </pre>
 * <p>Where:
 * <dl>
 * <dt>&lt;serviceName&gt;</dt><dd>a unique name within the broker for a service;
 *      the name {@code host} may not be used.</dd>
 * <dt>&lt;wildcardProcess&gt;</dt><dd>the name of a process in the process list;
 *      unknown processes are rerouted to this process. [optional]</dd>
 * <dt>&lt;processName&gt;</dt><dd>a unique name within the service for a process.</dd>
 * <dt>&lt;process config&gt;</dt><dd>the configuration for the process; see {@link Process}.</dd>
 * </dl>
 *
 * @author William
 * @since 2013-04
 */
class ConfigService
        implements Service {

    /** logger for events */
    private final Logger logger;
    /** Name of the service; used for routing messages */
    private final String name;
    /** Wildcard process for re-routing unknown messages */
    private final String wildcard;
    /** A link back to the broker that created this service */
    private MessageBroker messageBroker;
    /** The available processes */
    private final Map<String, ProcessAgent> processes;
    /** Indicate if the service is in a running state */
    private boolean running;

    /**
     * Create a new service from the supplied config.
     *
     * @param   name
     *          The name of the service.
     * @param   config
     *          the configuration for the service.
     * @throws  DataException
     *          when there is a problem in the configuration.
     * @throws  ProcessException
     *          when an exception occurs within the processes.
     */
    ConfigService (String name, ClassLoader classLoader, ConfigData config, FunctionLibrary functionLibrary)
            throws DataException, 
				ProcessException,
				ExpressionException, 
				ClassNotFoundException, 
				InstantiationException,
				IllegalAccessException {

        this.name = name;
        this.logger = new Logger(ConfigService.class.getSimpleName() , this.name);
        this.wildcard = config.getOptionalSetting(Config.WILDCARD);
        this.processes = new HashMap();
        ConfigData processList = config.getConfigData(Config.PROCESS_LIST);
        String[] processNames = processList.keys();
        for (int p = 0;
             p < processNames.length;
             p++) {
            ConfigData processConfig = processList.getConfigData(processNames[p]);
            this.processes.put(processNames[p],
                    new ProcessAgent(processNames[p],classLoader, processConfig, functionLibrary));
            processConfig.close();
        }
        processList.close();
        if (this.wildcard != null && !this.processes.containsKey(this.wildcard)) {
            throw new ProcessException("Config missing wildcard process: " + this.wildcard);
        }
        this.logger.info("Service initialised, wildcard ='" + this.wildcard +"'");
    }

    /**
     * Send a message back to the broker
     * <p>The message is sent back to the broker with {@link Context#RETURN}
     * set to the value of {@code returnMessage}.
     * <p>This method is used for bouncing back messages with any errors that occur.
     *
     * @param   message
     *          a message received from the broker.
     * @param   returnMessage
     *          a text message to send back.
     * @throws  IllegalArgumentException
     *          when the return message is missing.
     */
    private void bounceBack(DataSet message, String returnMessage) {
        this.logger.debug("bounceBack " + returnMessage ,message);
        message.put(Context.RETURN, returnMessage);
        message.put(Context.CLOSE, true);
        this.outbound(message);
    }

    @Override
    public void close() {
        this.logger.info("closing");

        // tell the sessions you're dead:
        for (ProcessAgent p : this.processes.values()) {
            p.close();
        }
        this.logger.info("closed");
    }

    @Override
    public Connection getConnection(String connectionName)
            throws ProcessException {
        return this.messageBroker.getConnection(connectionName);
    }

    @Override
    public void inbound(DataSet message) {
        this.logger.debug("inbound", message);
        if (!this.isRunning()) {
            this.bounceBack(message, "service is closed");
            return;
        }
        String messageName = message.getString(Context.MESSAGE);
        if (messageName == null) {
            this.bounceBack(message, "missing message");
            return;
        }
        ProcessAgent agent = this.processes.get(messageName);
        if (agent == null) {
            if (this.wildcard == null) {
                this.bounceBack(message, "unknown message");
                return;
            }
            agent = this.processes.get(this.wildcard);
        }
        agent.inbound(message);
    }

    /**
     * Indicates if the service is currently running.
     *
     * @return  {@code true} if the service is running,
     *          otherwise {@code false}.
     */
    public boolean isRunning() {
        return this.running;
    }

    @Override
    public void outbound (DataSet message) {
        this.logger.debug("outbound", message);
        this.messageBroker.outbound(message);
    }

    @Override
    public void setMessageBroker(MessageBroker messageBroker) {
        this.messageBroker = messageBroker;
    }

    /**
     * Method to set the running state of the broker and then notify of the change.
     *
     * @param   running
     *          {@code true} for the broker is running,
     *          otherwise {@code false}.
     */
    private synchronized void setRunning(boolean running) {
        this.logger.debug("setRunning " + running);
        this.running = running;
        this.notifyAll();
    }

    @Override
    public void start()
            throws ProcessException {
        this.logger.debug("starting...");
        for (ProcessAgent process : this.processes.values()) {
            process.setService(this);
            process.start();
        }
        this.setRunning(true);
        this.logger.debug("started");
    }
}


