/*
 * ================================================================================
 * Lexa - Property of William Norman-Walker
 * --------------------------------------------------------------------------------
 * ProcessAgent.java
 *--------------------------------------------------------------------------------
 * Author:  William Norman-Walker
 * Created: April 2013
 *--------------------------------------------------------------------------------
 * Change Log
 * Date:        By: Ref:        Description:
 * ----------   --- ----------  --------------------------------------------------
 * -            -   -           -
 *================================================================================
 */
package lexa.core.server;

import lexa.core.server.connection.Connection;
import java.util.*;
import lexa.core.data.ConfigData;
import lexa.core.data.DataItem;
import lexa.core.data.DataSet;
import lexa.core.data.exception.DataException;
import lexa.core.expression.ExpressionException;
import lexa.core.expression.function.FunctionLibrary;
import lexa.core.logging.Logger;
import lexa.core.queue.FIFOQueue;
import lexa.core.queue.Queue;
import lexa.core.server.context.Config;
import lexa.core.server.context.Context;
import lexa.core.server.factory.InternalLoader;
import lexa.core.server.process.Status;
import lexa.core.server.process.LexaProcess;
import lexa.core.server.factory.ProcessFactory;

/**
 * A process agent set up using configuration.
 * <p>The process is set up using config data provided by the {@link ConfigService}.
 * Each process agent handles a single message type.
 * <p>The process can be used for handling multiple messages by name but the action
 * will be the same based on the configuration.
 * <p>The configuration block for a process is:
 * <pre>
 * &lt;processName&gt; {
 *   [connectionName &lt;connectionName&gt;]
 *   classPath &lt;classPath&gt;
 *   [config {
 *     &lt;process config&gt;
 *   }
 * }
 * </pre>
 * <p>Where:
 * <dl>
 * <dt>&lt;processName&gt;</dt><dd>a unique name within the service for a process.</dd>
 * <dt>&lt;connectionName&gt;</dt><dd>the name of a message broker that this process will
 *      connect to for sending messages; the name may be {@code local}, for a loop back connection,
 *      or any named broker from the {@link MessageBroker} {@code brokerList} configuration block.
 *      [optional]</dd>
 * <dt>&lt;classPath&gt;</dt><dd>the class path for the {@link ProcessFactory}.</dd>
 * <dt>&lt;process config&gt;</dt><dd>the configuration for the process; see the implementations
 *      of {@link Process} for details.</dd>
 * </dl>
 *
 * @author William
 * @since 2013-04
 */
public class ProcessAgent
        extends Thread
        implements MessageSource {

    /** logger for events */
    private final Logger logger;
    /** the queue of inbound requests */
    private final Queue queue;
    /** Name of the process; used for routing messages */
    private final String name;
    /** the maximum number of child processes for this process */
    private final int maxProcesses;
    /** factory to produce processes */
    private final ProcessFactory factory;
    /** a list of processes used to handle messages */
    private final List<LexaProcess> processes;
    /** all outbound messages currently being processed */
    private final HashMap<Integer, Message> outboundMessages;
    /** the name of a {@link MessageBroker} that this can connect to for forwarding messages */
    private final String connectionName;
    /** the {@link MessageBroker} that this can connect to for forwarding messages */
    private Connection connection;
    /** a link back to the containing service */
    private Service service;
    /** Indicate if the service is in a running state */
    private boolean running;

    /**
     * Create a new process from the supplied config.
     *
     * @param   name
     *          The name of the process.
     * @param   config
     *          the configuration for the process.
     * @throws  DataException
     *          when there is a problem in the configuration.
     * @throws  ProcessException
     *          when an exception occurs within the processes.
     */
    public ProcessAgent(String name, ClassLoader classLoader, ConfigData config, FunctionLibrary functionLibrary)
            throws DataException,
				ProcessException,
				ExpressionException,
				ClassNotFoundException,
				InstantiationException,
				IllegalAccessException
	{
        this.name = name;
        this.logger = new Logger(ProcessAgent.class.getSimpleName(), this.name);
        this.connectionName = config.getOptionalSetting(Config.CONNECTION_NAME);
        this.queue = new FIFOQueue();
        this.processes = new LinkedList();
        this.outboundMessages = new HashMap();
        this.maxProcesses = config.contains(Config.MAX_PROCESSES) ?
				config.getItem(Config.MAX_PROCESSES).getInteger() :
				1;

        ConfigData processConfig = config.contains(Config.CONFIG) ?
                    config.getConfigData(Config.CONFIG) : null;
        this.factory = new ProcessFactory(
				classLoader,
                config.getOptionalSetting(Config.CLASS_LOADER,
						InternalLoader.class.getCanonicalName()),
                config.getSetting(Config.CLASS_PATH),
                processConfig, functionLibrary);
        if (processConfig != null) {
            processConfig.close();
        }
        // create the first process, this will ensure the config is clean and the factory sound.
        this.processes.add(factory.instance());
    }

    /**
     * Bounces a message back to the caller with a simple {@code return} value.
     * @param   message
     *          the original inbound message
     * @param   returnMessage
     *          a message to return to the caller
     */
    private void bounceBack(DataSet message, String returnMessage) {
        this.logger.debug("bounceBack " + returnMessage , message);
        message.put(Context.RETURN, returnMessage);
        message.put(Context.CLOSE, true);
        this.outbound(message);
    }

    /**
     * Close the service
     */
    public void close() {
        this.logger.info("Closing");
        this.setRunning(false);
        this.logger.info("closed");
    }

    /**
     * Process requests from the processes to the forward connection.
     * <p>The requests are in the format defined by {@link Process#getRequests()}
     *
     * @param   requests
     *          a set of requests to be sent.
     * @throws  ProcessException
     *          there was an error processing the messages:
     *          <ul>
     *          <li>no forward connection</li>
     *          </ul>
     */
    private void handleRequests(DataSet requests)
            throws ProcessException {
        this.logger.debug("Handle requests",requests);
        if (this.connection == null) {
            //this.logger.error("No forward connection for service", requests, null);
            throw new ProcessException("No forward connection for service", requests);
        }

        Integer sourceRef = requests.getInteger(Context.SOURCE_REF);
        DataSet messageList = requests.getDataSet(Context.MESSAGE_LIST);
        for (DataItem item : messageList) {
            DataSet messageData = new DataSet(item.getDataSet());
            messageData.put(Context.SOURCE_REF,sourceRef);
            Message message = new Message(this, messageData);
            int mid = this.connection.submit(message);
            this.outboundMessages.put(mid, message);
        }
    }

    /**
     * Submit an inbound message.
     *
     * <p>An inbound message is received from the {@link Service} and
     * will be put onto the queue to be processed by a {@link Process}.
     *
     * @param   message
     *          a {@link DataSet} containing the inbound message}
     */
    protected synchronized void inbound(DataSet message) {
        this.logger.debug("inbound", message);
        if (!this.isRunning()) {
            this.bounceBack(message, "process is closed");
            return;
        }
        this.queue.add(message);
        this.notifyAll();
    }

    /**
     * Indicates if the process is currently running.
     *
     * @return  {@code true] if the process is running,
     *          otherwise {@code false}.
     */
    public boolean isRunning() {
        return this.running;
    }


    /**
     * Submit an outbound message.
     *
     * <p>An outbound message is sent to the {@link Service}.
     * @param   message
     *          a {see DataSet} containing the outbound message}
     */
    protected void outbound(DataSet message) {
        this.logger.debug("outbound", message);
        this.service.outbound(message);
    }

    /**
     * Perform a single process pass of all the processes.
     * <p>A pass consists of looping through all the processes and giving them process time.
     * <p>If they are in a state to accept new messages this is the first step, then requests
     * are sent, processing performed and replies sent.
     * <p>If there are not enough processes to clear the inbound queue and the maximum number of
     * processes has not been reached, then a new process is created.
     * <p>If no processing occured, including creating new processes, then the thread sleeps until
     * the next notify is received.
     */
    private synchronized void process() throws ProcessException {

        // loop through the processes and see what they need to do:
        this.logger.debug("process");
        boolean busy = false;
        for (LexaProcess process : this.processes) {
            Status status = process.getStatus();
			
			try
			{
				if (status.acceptRequests() && !this.queue.isEmpty()) {
					DataSet request = this.queue.get();
					this.logger.debug("Submit request",request);
					process.handleRequest(request);
					busy = true;
				}
				if (status.requestPending()) {
					this.handleRequests(process.getRequests());
					busy = true;
				}
				if (status.waitingProcess()) {
					process.process();
					busy = true;
				}
				if (status.replyReady()) {
					this.outbound(process.getReply());
					busy = true;
				}
			}
			catch (ProcessException ex)
			{
				this.logger.error("Error in process call", process.getMessageData(), ex);
				// if the reply throws an exception it's no worry.  I think
				this.outbound(process.getReply());
				
			}
        }

        if (!this.queue.isEmpty() &&
                this.processes.size() < this.maxProcesses) {
            this.logger.debug("Create new process");
            try {
                this.processes.add(factory.instance());
                busy = true;
            } catch (DataException ex) {
                this.logger.error("Failed to create new process", ex);
            } catch (ExpressionException ex) {
                this.logger.error("Failed to parse process expression", ex);
            }
        }

        if (!busy) {
            this.logger.debug("Waiting");
            try {
                this.wait();
            } catch (InterruptedException ex) {
                this.logger.error("interupt",ex);
            }
            this.logger.debug("Wake up");
        }
    }

    /**
     * Run the process.
     * <p>See {@link Process#process()} for details.
     */
    @Override
    public void run() {
        this.logger.info("Running");
        while(this.running) {
			try
			{
				process();
			}
			catch (ProcessException ex)
			{
				this.logger.error("Exception proccessing a request", ex);
			}
        }
        this.logger.info("Stopped");
    }

    private synchronized void setRunning(boolean running) {
        this.running = running;
        this.notifyAll();
    }

    /**
     * Sets the {@link Service} that contains this process.
     * @param   service
     *          the service
     */
    void setService(Service service)
            throws ProcessException {
        this.service = service;
        if (this.connectionName != null) {
            this.connection = this.service.getConnection(this.connectionName);
        }
    }

    @Override
    public void start() {
        this.setRunning(true);
        super.start();
    }

    @Override
    public void messageClosed(Message message) {
        int sid = message.getSourceId();
        this.logger.debug("messageClosed " + sid);
        this.outboundMessages.remove(sid);
    }

    @Override
    public synchronized void replyReceived(Message message) {
        DataSet reply = message.getReply();
        int ref = message.getSourceReference();
        this.logger.debug("replyRecieved, process " + ref, reply);


        LexaProcess process = null;
        for (LexaProcess w : this.processes) {
            if (w.getId() == ref) {
                process = w;
                break;
            }
        }
        if (process == null) {
            this.logger.error("Reply received with no source process " + ref, reply, null);
        }
        try {
            process.handleReply(reply);
            this.notifyAll();
        } catch (ProcessException ex) {
            this.logger.error("Unable to submit reply", reply, ex);
        }
    }

    @Override
    public void updateReceived(Message message) {
        throw new UnsupportedOperationException("Process.updateReceived not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
