/*
 * ================================================================================
 * Lexa - Property of William Norman-Walker
 * --------------------------------------------------------------------------------
 * PassThrough.java
 *--------------------------------------------------------------------------------
 * Author:  William Norman-Walker
 * Created: July 2013
 *--------------------------------------------------------------------------------
 * Change Log
 * Date:        By: Ref:        Description:
 * ----------   --- ----------  --------------------------------------------------
 * -            -   -           -
 *================================================================================
 */
package lexa.core.server.worker;

import lexa.core.data.ConfigData;
import lexa.core.data.DataItem;
import lexa.core.data.DataSet;
import lexa.core.data.exception.DataException;
import lexa.core.expression.ExpressionParser;
import lexa.core.server.ProcessException;
import lexa.core.server.context.Config;
import lexa.core.server.context.Context;

/**
 * Provide a pass through process.  Each request is forwarded on to another service
 * on the remote connection for the process.
 * @author William
 * @since 2013-07
 */
public class PassThrough
        implements Worker {

    private final static String STATE_REPLY_READY       = "REPLY_READY";
    private final static String STATE_REQUEST_PENDING   = "REQUEST_PENDING";
    private final static String STATE_WAITING_REPLY     = "WAITING_REPLY";
    private final Status status;
    /** Unique id assigned to the worker */
    private int id;

    private int lastSid;
    private boolean allowAnonymous;
    private DataSet messageMap;
    private DataSet requests;

    public PassThrough() {
        this.status = new Status();
        this.lastSid = 0;
    }

    @Override
    public void close() throws ProcessException {
        this.status.setClosed();
    }

    @Override
    public int getId() {
        return this.id;
    }

    @Override
    public void initialise(ExpressionParser parser, ConfigData config) throws ProcessException, DataException {
        if (this.status.active() || this.status.closed()) {
            throw new ProcessException("Worker cannot be initialised in current state.");
        }
        this.allowAnonymous = config.getItem(Config.ALLOW_ANONYMOUS).getBoolean();
        this.messageMap = new DataSet();
        this.requests = new DataSet();
        ConfigData serviceConfig = config.getConfigData(Config.SERVICE_LIST);
        String[] keys = serviceConfig.keys();
        for (int k = 0;
                k < keys.length;
                k++) {
            String from = keys[k];
            String to = serviceConfig.getSetting(from);
            this.messageMap.put(from,to);
        }
        serviceConfig.close();
        this.status.setActive();
        this.status.setAcceptRequests(true);
    }

    @Override
    public DataSet getReply() throws ProcessException {
        if (!this.status.replyReady()) {
            throw new ProcessException("No reply ready");
        }
        DataSet reply = null;
        for (DataItem item : this.requests) {
            DataSet request = item.getDataSet();
            if (request.getBoolean(STATE_REPLY_READY)) {
                // set the reply:
                reply = new DataSet(request.getDataSet(Context.REQUEST));
                reply.put(request.get(Context.REPLY));
                reply.put(request.get(Context.RETURN));
                reply.put(request.get(Context.CLOSE));
                request.put(STATE_REPLY_READY,false);
                break;
            }
        }
        this.status.setReplyReady(false);
        this.status.setWaitingProcess(true);
        return reply;
    }

    @Override
    public DataSet getRequests() throws ProcessException {
        if (!this.status.requestPending()) {
            throw new ProcessException("No requests pending");
        }
        DataSet messageList = new DataSet();
        for (DataItem item : this.requests) {
            DataSet request = item.getDataSet();
            if (request.getBoolean(PassThrough.STATE_REQUEST_PENDING)) {
                DataSet data = new DataSet();
                data.put(request.get(Context.SERVICE));
                DataSet original = request.getDataSet(Context.REQUEST);
                data.put(original.get(Context.MESSAGE));

                DataSet clientSource = new DataSet();
                clientSource.put(original.get(Context.SERVICE));
                clientSource.put(original.get(Context.MESSAGE));
                clientSource.put(original.get(Context.SOURCE_ID));
                clientSource.put(original.get(Context.SOURCE_REF));
                clientSource.put(original.get(Context.SOURCE));
                DataSet source = new DataSet();
                source.put(request.get(Context.SOURCE_REF));
                source.put(Context.SOURCE,clientSource);
                data.put(Context.SOURCE,source);
                data.put(original.get(Context.REQUEST));

                messageList.put(item.getKey(),data);
                request.put(PassThrough.STATE_REQUEST_PENDING,false);
                request.put(PassThrough.STATE_WAITING_REPLY,true);
            }
        }
        this.status.setRequestPending(false);
        if (messageList.isEmpty()) {
            return null;
        }
        DataSet messages = new DataSet();
        messages.put(Context.SOURCE_REF, this.getId());
        messages.put(Context.MESSAGE_LIST,messageList);
        this.status.setRequestPending(false);
        this.status.setWaitingProcess(true);
        return messages;
    }

    @Override
    public Status getStatus() {
        return this.status;
    }

    @Override
    public void process() throws ProcessException {
        if (!this.status.waitingProcess()) {
            throw new ProcessException("No pending process");
        }
        // after each step, the status flags are reset and we come back here.
        // now check all requests for pending work;
        for (DataItem item : this.requests) {
            DataSet request = item.getDataSet();
            if (request.getBoolean(PassThrough.STATE_REPLY_READY)) {
                this.status.setReplyReady(true);
            }
            if (request.getBoolean(PassThrough.STATE_REQUEST_PENDING)) {
                this.status.setRequestPending(true);
            }
            if (request.getBoolean(PassThrough.STATE_WAITING_REPLY)) {
                this.status.setWaitingReply(true);
            }
        }
        this.status.setWaitingProcess(false);
    }

    @Override
    public void handleRequest(DataSet request) throws ProcessException {
        String from = request.getString(Context.MESSAGE);
        String to = this.messageMap.getString(from);
        if (to == null) {
            //if (!this.allowAnonymous) {
                throw new ProcessException("Unknown service", request);
            //}
            //to = from;
            //this.messageMap.put(from,to);
        }
        int sid = ++this.lastSid;
        DataSet data = new DataSet();
        data.put(Context.REQUEST, request);
        data.put(Context.SOURCE_REF, sid);
        data.put(Context.SERVICE,to);
        data.put(PassThrough.STATE_REQUEST_PENDING,true);
        data.put(PassThrough.STATE_WAITING_REPLY,false);
        data.put(PassThrough.STATE_REPLY_READY,false);
        this.requests.put(String.valueOf(sid),data);
        this.status.setWaitingProcess(true);
    }

    @Override
    public void handleReply(DataSet reply) throws ProcessException {
        if (!this.status.waitingReply()) {
            throw new ProcessException("No replies waiting");
        }

        DataSet source = reply.getDataSet(Context.SOURCE);
        DataSet request = this.requests.getDataSet(String.valueOf(source.getInteger(Context.SOURCE_REF)));
        request.put(reply.get(Context.REPLY));
        request.put(reply.get(Context.RETURN));
        request.put(reply.get(Context.CLOSE));
        request.put(PassThrough.STATE_WAITING_REPLY,false);  // maybe not?
        request.put(PassThrough.STATE_REPLY_READY,true);

        this.status.setWaitingProcess(true);
    }

    @Override
    public void setId(int id) {
        this.id = id;
    }
}
