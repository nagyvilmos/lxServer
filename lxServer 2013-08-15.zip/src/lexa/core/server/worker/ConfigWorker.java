/*
 * ================================================================================
 * Lexa - Property of William Norman-Walker
 * --------------------------------------------------------------------------------
 * ConfigWorker.java
 *--------------------------------------------------------------------------------
 * Author:  William Norman-Walker
 * Created: August 2013
 *--------------------------------------------------------------------------------
 * Change Log
 * Date:        By: Ref:        Description:
 * ----------   --- ----------  --------------------------------------------------
 * -            -   -           -
 *================================================================================
 */
package lexa.core.server.worker;

import java.util.HashMap;
import java.util.Map;
import lexa.core.data.ConfigData;
import lexa.core.data.DataItem;
import lexa.core.data.DataSet;
import lexa.core.data.exception.DataException;
import lexa.core.expression.Expression;
import lexa.core.expression.ExpressionException;
import lexa.core.expression.ExpressionParser;
import lexa.core.server.ProcessException;
import lexa.core.server.context.Config;
import lexa.core.server.context.Context;

/**
 * A worker that is managed via config.
 * <p>Each step on the process is configured using an {@link lexa.core.expression.Expression}
 * to determine the outcome.
 * <p>The configuration of this is as follows:
 * <pre>
 * handleRequest &lt;handleRequest expression&ft;
 * data {
 *   &lt;data config&ft;
 * }
 * </pre>
 * <dl>
 * <dt>&lt;handleRequest expression&gt;</dt><dd>an expression to determine if the request is valid.
 *          This must return {@code true} or {@code false}.</dd>
 * <dt>&lt;data config&gt;</dt><dd>any data used to drive the configuration; such as look up codes.</dd>
 * </dl>
 * @author William
 * @since 2013-08
 */
public class ConfigWorker
        extends RequestWorker {

    /** the current message being processed */
    private DataSet message;

    private Expression handleRequest;
    private Map<String,Expression> requests;
    private Expression checkNextRequest;
    private DataSet data;

    public ConfigWorker() {
    }

    @Override
    public void close() throws ProcessException {
        throw new UnsupportedOperationException("ConfigWorker.close not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public DataSet getReply() throws ProcessException {
        throw new UnsupportedOperationException("ConfigWorker.getReply not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public DataSet getRequests() throws ProcessException {
        throw new UnsupportedOperationException("ConfigWorker.getRequests not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void handleReply(DataSet reply) throws ProcessException {
        throw new UnsupportedOperationException("ConfigWorker.handleReply not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public DataSet buildReply() throws ProcessException {
        throw new UnsupportedOperationException("ConfigWorker.buildReply not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public DataSet buildRequests() throws ProcessException {
        String requestName = this.message.getString(Config.NEXT_REQUEST);
        Expression requestBuilder =
                this.requests.get(requestName);
        if (requestBuilder == null) {
            throw new ProcessException("Cannot find handler for " + requestName);
        }
        try {
            return (DataSet)requestBuilder.evaluate(this.message);
        } catch (ExpressionException ex) {
            throw new ProcessException(ex.getLocalizedMessage(),this.message,ex);
        }
    }

    @Override
    public boolean hasForwardRequests() throws ProcessException {
        if (this.checkNextRequest == null) {
            return false;
        }
        String next;
        try {
            next = (String)this.checkNextRequest.evaluate(message);
        } catch (ExpressionException ex) {
            throw new ProcessException(ex.getLocalizedMessage(),this.message,ex);
        }
        if (next != null) {
            message.put(Config.NEXT_REQUEST,next);
            return true;
        }
        return false;
    }

    @Override
    public boolean hasFurtherWork() throws ProcessException {
        throw new UnsupportedOperationException("ConfigWorker.hasFurtherWork not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void onClose() throws ProcessException {
        throw new UnsupportedOperationException("ConfigWorker.onClose not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void onInitialise(ExpressionParser parser, ConfigData config)
            throws ProcessException,
                    DataException,
                    ExpressionException {
        this.handleRequest = parser.getExpression(
                config.getOptionalSetting(Config.HANDLE_REQUEST, "true"));
        this.requests = new HashMap<String, Expression>();
        if (config.contains(Config.REQUEST_LIST)) {
            this.checkNextRequest = parser.getExpression(
                    config.getSetting(Config.NEXT_REQUEST));
            ConfigData requestConfig = config.getConfigData(Config.REQUEST_LIST);
            for (DataItem item : requestConfig.getAll()) {
                this.requests.put(item.getKey(), parser.getExpression(item.getString()));
            }
        }
        if (config.contains(Config.DATA)) {
            this.data = config.getConfigData(Config.DATA).getAll();
        }
    }

    @Override
    public void onNewRequest(DataSet request) throws ProcessException {
        this.message = new DataSet();
        this.message.put(Config.DATA, this.data);
        this.message.put(Context.REQUEST,request);
        this.message.put(Config.NEXT_REQUEST,null);
        try {
            if (!(Boolean)this.handleRequest.evaluate(message)) {
                if (this.message.contains(Context.RETURN)) {
                    throw new ProcessException(message.getString(Context.RETURN),message);
                }
                throw new ProcessException("Unhandled request",message);
            }
        } catch (ExpressionException ex) {
            throw new ProcessException(ex.getLocalizedMessage(),message,ex);
        }
    }

    @Override
    public boolean onReply(DataSet reply) throws ProcessException {
        throw new UnsupportedOperationException("ConfigWorker.onReply not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void onProcess() throws ProcessException {
        throw new UnsupportedOperationException("ConfigWorker.onProcess not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
