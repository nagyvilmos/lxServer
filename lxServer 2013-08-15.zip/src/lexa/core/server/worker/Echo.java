/*
 * ================================================================================
 * Lexa - Property of William Norman-Walker
 * --------------------------------------------------------------------------------
 * Echo.java
 *--------------------------------------------------------------------------------
 * Author:  William Norman-Walker
 * Created: April 2013
 *--------------------------------------------------------------------------------
 * Change Log
 * Date:        By: Ref:        Description:
 * ----------   --- ----------  --------------------------------------------------
 * 2013-08-10   WNW -           Changed to use RequestWorker
 *================================================================================
 */
package lexa.core.server.worker;

import lexa.core.data.ConfigData;
import lexa.core.data.DataSet;
import lexa.core.data.exception.DataException;
import lexa.core.expression.ExpressionException;
import lexa.core.expression.ExpressionParser;
import lexa.core.server.ProcessException;
import lexa.core.server.context.Context;

/**
 * Test process using a simple echo.
 * <p>Configured as:
 * <pre>
 * &lt;process&gt; {
 *   name &lt;process description&gt;
 *   classPath internal:echo
 * }
 * </pre>
 *
 * <p>The returned reply will be a copy of the request; no further processing takes place.
 *
 * @author William
 * @since 2013-04
 */
public class Echo
        extends RequestWorker {

    private DataSet context;
    /** the last reply created */
    private DataSet reply;

    @Override
    public DataSet buildReply() throws ProcessException {
        DataSet replyContext = new DataSet(this.context);
        replyContext.put(Context.REPLY,this.reply);
        return replyContext;
    }

    @Override
    public DataSet buildRequests() throws ProcessException {
        return null;
    }

    @Override
    public boolean hasForwardRequests() throws ProcessException {
        return false; // never has any
    }

    @Override
    public boolean hasFurtherWork() throws ProcessException {
        return false;
    }

    @Override
    public void onClose() throws ProcessException {
        // no special processing
    }

    @Override
    public void onInitialise(ExpressionParser parser, ConfigData config)
            throws ProcessException,
                    DataException,
                    ExpressionException {
        // no special processing
    }

    @Override
    public void onNewRequest(DataSet request) throws ProcessException {
        this.context = request;
    }

    @Override
    public boolean onReply(DataSet reply) throws ProcessException {
        return true;
    }

    @Override
    public void onProcess() throws ProcessException {
        this.reply = new DataSet(this.context.getDataSet(Context.REQUEST));
    }
}
