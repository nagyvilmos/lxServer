/*
 * ================================================================================
 * Lexa - Property of William Norman-Walker
 * --------------------------------------------------------------------------------
 * RequestWorker.java
 *--------------------------------------------------------------------------------
 * Author:  William Norman-Walker
 * Created: August 2013
 *--------------------------------------------------------------------------------
 * Change Log
 * Date:        By: Ref:        Description:
 * ----------   --- ----------  --------------------------------------------------
 * -            -   -           -
 *================================================================================
 */
package lexa.core.server.worker;

import lexa.core.data.ConfigData;
import lexa.core.data.DataSet;
import lexa.core.data.exception.DataException;
import lexa.core.expression.ExpressionException;
import lexa.core.expression.ExpressionParser;
import lexa.core.server.ProcessException;
import lexa.core.server.context.Context;

/**
 * A request worker implements a basic worker that receives requests and processes them.
 * <p>This handles the status of the worker and allows the implementation to concentrate
 * on handling the data flow.

* @author William
 * @since 2013-08
 */
public abstract class RequestWorker
        implements Worker {

    /** the current status */
    private final Status status;
    /** Unique id assigned to the worker */
    private int id;

    /**
     * creates a new worker
     */
    public RequestWorker() {
        this.status = new Status();
    }

    /**
     * Method to build a new reply.
     * <p>This is called by {@link RequestWorker#getReply() getReply} and the results
     * from this method are returned by it.
     *
     * @return  The data for the reply.
     * @throws  ProcessException
     *          when an exception occurs building the reply.
     */
    public abstract DataSet buildReply() throws ProcessException;

    /**
     * Method to build outstanding requests.
     * <p>This is called by {@link RequestWorker#getRequests() getRequests} and the results
     * from this method are returned by it.
     * <p>This is only called if the status has pending requests; the flag is reset after this is called.
     *
     * @return  The data for the requests; see {@link Worker#getRequests()}.
     * @throws ProcessException
     *          when an exception occurs building the requests.
     */
    public abstract DataSet buildRequests() throws ProcessException;

    @Override
    public void close() throws ProcessException {
        this.onClose();
        this.status.closed();
    }

    @Override
    public int getId() {
        return this.id;
    }

    @Override
    public DataSet getReply() throws ProcessException {
        if (!this.status.replyReady()) {
            throw new ProcessException("Worker has no replies ready.");
        }
        DataSet reply = this.buildReply();

        this.status.setReplyReady(false);
        if (this.hasFurtherWork()) {
            this.status.setWaitingProcess(true);
        } else {
            reply.put(Context.CLOSE,true);
            this.status.setAcceptRequests(true);
        }
        return reply;
    }

    @Override
    public DataSet getRequests() throws ProcessException {
        if (!this.status.requestPending()) {
            throw new ProcessException("Worker has no pending requests.");
        }
        DataSet requests = this.buildRequests();
        this.status.setRequestPending(false);
        this.status.setReplyReady(false);
        return requests;
    }

    @Override
    public Status getStatus() {
        return this.status;
    }

    @Override
    public void handleReply(DataSet reply) throws ProcessException {
        if (!this.status.waitingReply()) {
            throw new ProcessException("Worker cannot accept requests.");
        }
        if (this.onReply(reply)) {
            this.status.setWaitingReply(false);
        }
        this.status.setWaitingProcess(true);

    }

    @Override
    public void handleRequest(DataSet request) throws ProcessException {
        if (!this.status.acceptRequests()) {
            throw new ProcessException("Worker cannot accept requests.");
        }
        this.onNewRequest(request);
        this.status.setAcceptRequests(false);
        if (this.hasForwardRequests()) {
            this.status.setRequestPending(true);
        } else {
            this.status.setWaitingProcess(true);
        }
    }

    /**
     * Indicates if there are any requests needed to be built.
     * <p>This is called after {@link RequestWorker#onNewRequest(lexa.core.data.DataSet) onNewRequest}
     * and {@link RequestWorker#onProcess() onProcess} to determine if any more requests are now needed.
     *
     * @return  {@code true} if requests are needed,
     *          otherwise {@code false}.
     * @throws  ProcessException
     *          when an exception occurs determining if there are more requests.
     */
    public abstract boolean hasForwardRequests() throws ProcessException;

    /**
     * Called to determine if the worker has further work after replying.
     *
     * @return  {@code true} if the worker has further,
     *          otherwise {@code false}.
     * @throws  ProcessException
     *          when an exception occurs checking for further work.
     */
    public abstract boolean hasFurtherWork() throws ProcessException;

    @Override
    public void initialise(ExpressionParser parser, ConfigData config)
            throws ProcessException,
                    DataException,
                    ExpressionException {
        if (this.status.active() || this.status.closed()) {
            throw new ProcessException("Worker cannot be initialised in current state.");
        }
        this.onInitialise(parser, config);
        this.status.setActive();
        this.status.setAcceptRequests(true);
    }

    /**
     * Called when the worker is being closed.
     * <p>Use this method in preference to overriding {@link Worker#close() close}.
     *
     * @throws  ProcessException
     *          when an exception occurs closing the worker.
     */
    public abstract void onClose()throws ProcessException;

    /**
     * Called when the worker is being initialised.
     * <p>Use this method in preference to overriding
     * {@link Worker#initialise(lexa.core.data.ConfigData) initialise}.
     *
     * @param   config
     *          the configuration data for the worker.
     * @throws  ProcessException
     *          when an exception occurs initialising the worker.
     * @throws  DataException
     *          when an exception occurs in the configuration.
     */
    public abstract void onInitialise(ExpressionParser parser, ConfigData config)
            throws ProcessException,
                    DataException,
                    ExpressionException;

    /**
     * Called when the worker receives a new request.
     * <p>Use this method in preference to overriding
     * {@link Worker#handleRequest(lexa.core.data.DataSet) handleRequest}.
     *
     * @param   request
     *          the data for the request.
     * @throws  ProcessException
     *          when an exception occurs handling the request.
     */
    public abstract void onNewRequest(DataSet request) throws ProcessException;

    /**
     * Called when the worker receives a new reply.
     * <p>Use this method in preference to overriding
     * {@link Worker#handleReply(lexa.core.data.DataSet) handleReply}.
     *
     * @param   reply
     *          the data for the reply.
     * @throws  ProcessException
     *          when an exception occurs handling the reply.
     */
    public abstract boolean onReply(DataSet reply) throws ProcessException;

    /**
     * Called when the worker needs to perform some work.
     *
     * @throws  ProcessException
     *          when an exception occurs performing the processing.
     */
    public abstract void onProcess()throws ProcessException;

    @Override
    public void process() throws ProcessException {
        if (!this.status.waitingProcess()) {
            throw new ProcessException("Worker is not waiting to process.");
        }
        this.onProcess();
        this.status.setWaitingProcess(false);
        if (this.hasForwardRequests()) {
            this.status.setRequestPending(true);
        } else {
            this.status.setReplyReady(true);
        }

    }

    @Override
    public void setId(int id) {
        this.id = id;
    }

}
