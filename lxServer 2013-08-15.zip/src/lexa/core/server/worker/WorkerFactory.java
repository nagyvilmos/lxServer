/*
 * ================================================================================
 * Lexa - Property of William Norman-Walker
 * --------------------------------------------------------------------------------
 * WorkerFactory.java
 *--------------------------------------------------------------------------------
 * Author:  William Norman-Walker
 * Created: April 2013
 *--------------------------------------------------------------------------------
 * Change Log
 * Date:        By: Ref:        Description:
 * ----------   --- ----------  --------------------------------------------------
 * 2013-09-04   WNW -           Moved the initialisation of the worker in here
 *                              where it belongs.
 *================================================================================
 */
package lexa.core.server.worker;

import java.net.URL;
import java.net.URLClassLoader;
import lexa.core.data.ConfigData;
import lexa.core.data.DataItem;
import lexa.core.data.DataSet;
import lexa.core.data.ValueType;
import lexa.core.data.exception.DataException;
import lexa.core.expression.ExpressionException;
import lexa.core.expression.ExpressionParser;
import lexa.core.logging.Logger;
import lexa.core.server.ProcessException;

/**
 * A factory for creating and initialising workers.
 *
 * @author William
 * @since 2013-04
 */
public class WorkerFactory {

    private static int lastWorkerId = 0;
    private static int getNextWorkerId() {
        return ++WorkerFactory.lastWorkerId;
    }
    private final ExpressionParser parser;

    /**
     * Defining enum for the type of factory.
     * <p>If this is for an internal class then it can
     */
    private enum FactoryType {

        ECHO("internal:Echo") {
            @Override
            Worker instance() {
                return new Echo();
            }
        },
        PASS_THROUGH("internal:PassThrough") {
            @Override
            Worker instance() {
                return new PassThrough();
            }
        },
        CONFIG("internal:Config") {
            @Override
            Worker instance() {
                return new ConfigWorker();
            }
        },
        EXTERNAL(null) {
            @Override
            Worker instance() {
                return null;
            }
        };
        private final String classPath;

        private FactoryType(String classPath) {
            this.classPath = classPath;
        }

        abstract Worker instance();

        static FactoryType typeFromClassPath(String classPath) {
            for (int t = 0;
                    t < FactoryType.values().length;
                    t++) {
                if (FactoryType.values()[t].classPath.equals(classPath)) {
                    return FactoryType.values()[t];
                }
            }
            return FactoryType.EXTERNAL;
        }
    }

    private final Logger logger;
    private final String classPath;
    /** the configuration, as a {@link DataSet}, for all the workers */
    private final DataSet workerConfig;
    private final FactoryInterface factory;

    /**
     * Creates a factory for instantiating workers.
     *
     * <p>The path can be either one of the internal workers or a path and class name
     * in the format {@code drive://path//example.jar#com.example.ExampleWorker}.
     *
     * @param   classPath
     *          the path for the worker to be loaded
     * @param   config
     *          the configuration required by the worker
     * @param   parser
     *          Expression parser for the worker to use
     * @throws  DataException
     *          when an exception occurs reading the configuration.
     */
    public WorkerFactory(String classPath, ConfigData config, ExpressionParser parser)
            throws DataException {
        this.logger = new Logger(WorkerFactory.class.getSimpleName(), classPath);
        this.classPath = classPath;
        FactoryInterface fi;
        FactoryType ft = FactoryType.typeFromClassPath(classPath);
        if (ft != FactoryType.EXTERNAL) {
            fi = new InternalFactory(ft);
        } else {
            fi = new ExternalFactory();
        }
        this.factory = fi;

        this.parser = (ft != FactoryType.CONFIG) ?
                null :
                parser;

        this.workerConfig = config == null ?
                null :
                config.getAll();
    }

    /**
     * Get a new initialised instance of the worker.
     * <p>A new instance of the worker is instantiated and
     * then given its configuration via a call to
     * {@link Worker#initialise(lexa.core.data.ConfigData) initialise(ConfigData)}.
     *
     * @return  a new initialised instance of the worker
     *
     * @throws  ProcessException
     *          when the worker failed to initialise
     * @throws  DataException
     *          when a problem occured reading the configuration.
     */
    public Worker instance()
            throws ProcessException,
                    DataException,
                    ExpressionException {
        Worker worker = this.factory.instance();
        if (this.workerConfig == null) {
            worker.initialise(null,null);
        } else {
            worker.initialise(this.parser,
                    new ConfigData(this.workerConfig));
        }
        worker.setId(WorkerFactory.getNextWorkerId());
        return worker;
    }

    /**
     * Interface for the factory builder.
     */
    private interface FactoryInterface {

        public Worker instance()
                throws ProcessException;
    }

    private class InternalFactory
            implements FactoryInterface {

        private final FactoryType factory;

        InternalFactory(FactoryType factory) {
            logger.debug("InternalFactory");
            this.factory = factory;
        }

        @Override
        public Worker instance() {
            return this.factory.instance();
        }
    }

    private class ExternalFactory
            implements FactoryInterface {

        private final Class<?> classDefinition;

        private ExternalFactory() {
            logger.debug("ExternalFactory");
            Class<?> c = null;
            String[] split = classPath.split("#");
            if (split.length != 2) {
                logger.error("Class path not in the format 'jarPath#className'\n" + classPath);
                throw new IllegalArgumentException("Class path not in the format 'jarPath#className'");
            }
            try {
                URLClassLoader classLoader = URLClassLoader.newInstance(
                        new URL[]{new URL(split[0])});
                c = classLoader.loadClass(split[1]);
            } catch (Exception ex) {
                logger.error("Unable to locate class loader for " + classPath, ex);
                throw new IllegalArgumentException("Unable to locate class loader for " + classPath, ex);
            }
            this.classDefinition = c;
        }

        @Override
        public Worker instance()
                throws ProcessException{
            try {
                return (Worker)this.classDefinition.newInstance();
            } catch (Exception ex) {
                logger.error("Cannot create new instance for " + classPath, ex);
                throw new ProcessException("Cannot create new instance for " + classPath,ex);
            }
        }
    }
}
