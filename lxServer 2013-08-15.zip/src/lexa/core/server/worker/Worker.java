/*
 * ================================================================================
 * Lexa - Property of William Norman-Walker
 * --------------------------------------------------------------------------------
 * Worker.java
 *--------------------------------------------------------------------------------
 * Author:  William Norman-Walker
 * Created: April 2013
 *--------------------------------------------------------------------------------
 * Change Log
 * Date:        By: Ref:        Description:
 * ----------   --- ----------  --------------------------------------------------
 * -            -   -           -
 *================================================================================
 */
package lexa.core.server.worker;

import lexa.core.data.ConfigData;
import lexa.core.data.DataSet;
import lexa.core.data.exception.DataException;
import lexa.core.expression.ExpressionException;
import lexa.core.expression.ExpressionParser;
import lexa.core.server.ProcessException;

/**
 * Interface for a worker in a message server.
 * <p>The workers are instantiated and controlled by a {@link lexa.core.server.Process}.
 * <p>Each worker defines how many concurrent requests it can handle.  If there are more
 * requests than workers, then the process can create extra workers to handle the load.
 *
 * @author William
 * @since 2013-04
 */
public interface Worker {

    /**
     * Close the worker; no further calls should be accepted after this call.
     *
     * @throws  ProcessException
     *          when an exception occurs during processing.
     */
    public void close()
            throws ProcessException;

    /**
     * Get the unique ID assigned to the worker.
     * @return  the unique ID assigned to the worker
     */
    public int getId();

    /**
     * Get a reply to be returned to the caller.
     *
     * @return  the data for the reply.
     *
     * @throws  ProcessException
     *          when an exception occurs during processing.
     */
    public DataSet getReply()
            throws ProcessException;

    /**
     * Get a set of requests to be sent onto another process.
     * <p>The format is:
     * <pre>
     * sourceRef &lt;workerId&gt;
     * messageList {
     *   &lt;messageId&gt; {
     *     service &lt;service&gt;
     *     message &lt;message&gt;
     *     source {
     *       &lt;source data&gt;
     *     }
     *     request {
     *       &lt;request data&gt;
     *     }
     *   }
     *   [...]
     * }
     * </pre>
     * <p>Where:
     * <dl>
     * <dt>&lt;workerId&gt;</dt><dd>unique id assigned to the worker.</dd>
     * <dt>&lt;messageId&gt;</dt><dd>id assigned by the worker for the message.
     *      This block can be repeated with multiple unique message ids.</dd>
     * <dt>&lt;service&gt;</dt><dd>service for processing the message.</dd>
     * <dt>&lt;message&gt;</dt><dd>message type being sent.</dd>
     * <dt>&lt;source data&gt;</dt><dd>the source for the message; this is taken from the
     *      message being processed that generated the request.</dd>
     * <dt>&lt;request&gt;</dt><dd>the request message; this is defined by the
     *      relevant {@link Worker} implementation.</dd>
     * </dl>
     *
     * @return  a set of requests to be sent onto another process
     *
     * @throws  ProcessException
     *          when an exception occurs during processing.
     */
    public DataSet getRequests()
            throws ProcessException;

    /**
     * Get the status if the worker
     * @return  the status if the worker
     */
    public Status getStatus();

    /**
     * Handle a reply from a forwarded messages.
     *
     * @param   reply
     *          a reply from a forwarded messages
     *
     * @throws  ProcessException
     *          when an exception occurs during processing.
     */
    public void handleReply(DataSet reply)
            throws ProcessException;

    /**
     * Handle a request made to the worker.
     *
     * @param   request
     *          a request made to the worker
     *
     * @throws  ProcessException
     *          when an exception occurs during processing.
     */
    public void handleRequest(DataSet request)
            throws ProcessException;

    /**
     * Initialise the worker based on the configuration.
     *
     * @param   config
     *          the configuration for the worker.
     *
     * @throws  ProcessException
     *          when an exception has occurred initialising the worker.
     * @throws  DataException
     *          when an exception occurs in the configuration.
     */
    public void initialise(ExpressionParser parser, ConfigData config)
            throws ProcessException,
                    DataException,
                    ExpressionException;

    /**
     * Perform any processing of the data received.
     *
     * @throws  ProcessException
     *          when an exception occurs during processing.
     */
    public void process()
            throws ProcessException;

    /**
     * Set the unique ID for the worker.
     * @param   id
     *          the unique ID assigned to the worker
     */
    public void setId(int id);
}
