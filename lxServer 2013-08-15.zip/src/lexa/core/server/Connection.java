/*
 * ================================================================================
 * Lexa - Property of William Norman-Walker
 * --------------------------------------------------------------------------------
 * Connection.java
 *--------------------------------------------------------------------------------
 * Author:  William Norman-Walker
 * Created: May 2013
 *--------------------------------------------------------------------------------
 * Change Log
 * Date:        By: Ref:        Description:
 * ----------   --- ----------  --------------------------------------------------
 * -            -   -           -
 *================================================================================
 */
package lexa.core.server;

import java.util.*;
import lexa.core.data.DataSet;
import lexa.core.server.context.Context;
import lexa.core.server.context.Value;

/**
 * A connection into the {@link MessageBroker} for submitting messages.
 * <p>Connections are created by the broker and used by the external process to submit messages.
 *
 * @since   2013.04
 * @author  William NW
 */
public class Connection {
    /** unique id for the connection */
    private final int id;
    /** the current messages for the connection. */
    private final Map<Integer,Message> messages;
    /** the broker for submitting messages */
    private final MessageBroker messageBroker;
    /** the id of the last message sent */
    private int lastMessage;

    /**
     * Create a now connection into a broker with a given id.
     *
     * @param   messageBroker
     *          the broker for the connection to submit messages.
     * @param   id
     *          the unique id for the connection.
     */
    Connection(MessageBroker messageBroker, int id) {
        this.id = id;
        this.messages = new HashMap<Integer, Message>();
        this.messageBroker = messageBroker;
        this.lastMessage = 0;
    }

    /**
     * Close the connection.
     */
    public synchronized void close() {
        if (this.messages.isEmpty()) {
            return;
        }
        Integer[] keys = this.messages.keySet().toArray(new Integer[0]);
        for (int k = 0;
                k < keys.length;
                k++) {
            this.closeMessage(keys[k]);
        }
    }

    /**
     * Close a message session.
     * @param   sid
     *          the session id for the message.
     */
    public synchronized void closeMessage(int sid) {
        // this should submit a message back to the host.
        Message message = this.messages.remove(sid);
        if (message == null) {
            return;
        }
        DataSet close = message.getHeader(this.id, sid);

        close.put(Context.SYSTEM_REQUEST, Value.CLOSE_MESSAGE);
        this.messageBroker.inbound(close);
        message.close();
    }

    /**
     * Add a reply for a message.
     *
     * @param   reply
     *          The reply to a message.
     */
    synchronized void reply(DataSet reply) {
        int sid = reply.getInteger(Context.SOURCE_ID);
        Message message = this.messages.get(sid);
        if (message == null) {
            return;
        }
        message.addReply(reply);

        if (reply.getBoolean(Context.CLOSE)) {
            this.messages.remove(sid);
        }
    }

    /**
     * Submit a message to the message broker
     * <p>The message is given a unique session id for the connection.
     * There is no guarantee that all the session ids will be unique across
     * different sessions, but the connection and session ids together will
     * always be unique for the life of the broker..

     * @param   message
     *          a`{@link Message} to submit for processing.
     * @return  the session id for the message.
     */
    public synchronized int submit(Message message) {
        int sid = ++this.lastMessage;
        DataSet request = message.getRequest(this.id, sid);
        this.messages.put(sid,message);
        this.messageBroker.inbound(request);
        return sid;
    }

    void timeout(int sid) {
        DataSet timeoutMessage = new DataSet();
        timeoutMessage.put(Context.SOURCE_ID,sid);
        timeoutMessage.put(Context.RETURN,"message timed out with no response");
        this.reply(timeoutMessage);
        this.closeMessage(sid);

    }
}
