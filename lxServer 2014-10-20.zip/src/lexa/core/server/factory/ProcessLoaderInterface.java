/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package lexa.core.server.factory;

import lexa.core.data.ConfigData;
import lexa.core.data.exception.DataException;
import lexa.core.server.process.LexaProcess;
/**
 *
 * @author william
 */
public interface ProcessLoaderInterface
{
	void initialise(String classPath)
			throws DataException;
	LexaProcess getInstance()
			throws DataException;
}
