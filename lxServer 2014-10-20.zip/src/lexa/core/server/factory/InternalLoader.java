/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package lexa.core.server.factory;

import lexa.core.data.exception.DataException;
import lexa.core.server.context.Value;
import lexa.core.server.process.ConfigProcess;
import lexa.core.server.process.Echo;
import lexa.core.server.process.PassThrough;
import lexa.core.server.process.LexaProcess;

/**
 *
 * @author william
 */
public class InternalLoader
		implements ProcessLoaderInterface
{
	private Loader loader;

	@Override
	public void initialise(String classPath)
			throws DataException
	{
		switch (classPath)
		{
			case Value.CLASS_CONFIG :
			{
				this.loader = new Loader() {
					@Override
					public LexaProcess get()
					{
						return new ConfigProcess();
					}
				};
				break;
			}
			case Value.CLASS_ECHO :
			{
				this.loader = new Loader() {
					@Override
					public LexaProcess get()
					{
						return new Echo();
					}
				};
				break;
			}
			case Value.CLASS_PASS_THROUGH :
			{
				this.loader = new Loader() {
					@Override
					public LexaProcess get()
					{
						return new PassThrough();
					}
				};
				break;
			}
		}
	}

	@Override
	public LexaProcess getInstance()
			throws DataException
	{
		return this.loader.get();
	}
	
	private interface Loader
	{
		LexaProcess get();
	}
}
